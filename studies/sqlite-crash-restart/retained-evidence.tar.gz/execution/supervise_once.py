"""One admitted matrix invocation, separate owned process group, 190s deadline."""
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

BASE = Path('<WORKSPACE>')
SOURCE = BASE / 'timeout-crash-restart-predata-20261025'
OUT = BASE / 'timeout-crash-restart-run-v1-20261025'
HERE = BASE / 'timeout-crash-restart-execution-20261025'
ADMISSION = BASE / 'checkpoint-0730-independent-review/timeout-admission.json'
if OUT.exists():
    raise SystemExit('Refusing existing output: no reruns')
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER; this supervisor only.
    raise OSError(ctypes.get_errno(), 'Cannot establish owned-child reaping')
started = time.monotonic()
record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_freeze_sha256': hashlib.sha256((SOURCE/'PRE_DATA_FREEZE.json').read_bytes()).hexdigest(),
          'supervisor_pid': os.getpid(), 'external_timeout_s': 190,
          'invocations': 1, 'out': str(OUT), 'timed_out': False, 'reaped_adopted_children': []}
command = [sys.executable, '-B', str(SOURCE/'runner.py'), '--out', str(OUT), '--admission', str(ADMISSION)]
record['command'] = command
with (HERE/'runner-stdout.txt').open('xb') as stdout, (HERE/'runner-stderr.txt').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=SOURCE, stdout=stdout, stderr=stderr,
                               start_new_session=True, env={'PYTHONDONTWRITEBYTECODE':'1','LANG':'C.UTF-8'})
    record['driver_pid'] = process.pid
    record['owned_process_group'] = process.pid
    try:
        record['driver_exit'] = process.wait(timeout=190)
    except subprocess.TimeoutExpired:
        record['timed_out'] = True
        os.killpg(process.pid, signal.SIGKILL)
        record['driver_exit'] = process.wait(timeout=2)
    finally:
        # The session contains only the runner and service children it launched.
        try:
            os.killpg(process.pid, 0)
            record['remaining_owned_group_after_driver'] = True
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            record['remaining_owned_group_after_driver'] = False
        end = time.monotonic() + 2
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                record['all_owned_children_reaped'] = True
                break
            if pid:
                record['reaped_adopted_children'].append({'pid':pid, 'wait_status':status})
                continue
            if time.monotonic() >= end:
                record['all_owned_children_reaped'] = False
                break
            time.sleep(0.01)
record['elapsed_s'] = time.monotonic()-started
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (HERE/'supervisor-receipt.json').open('x') as stream:
    json.dump(record,stream,indent=2,sort_keys=True); stream.write('\n')
print(json.dumps(record,indent=2,sort_keys=True))
raise SystemExit(0 if record['driver_exit']==0 and not record['timed_out'] and record['all_owned_children_reaped'] and not record['remaining_owned_group_after_driver'] else 1)
