"""Post-measurement negative controls; separate from the 120-trial denominator."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
frozen = root.parent / 'source-at-measurement'
cases = (
    ('disable_key_deduplication', "old = db.execute('SELECT digest, effect_id FROM keys WHERE key=?', (key,)).fetchone() if key is not None else None", 'old = None',
     'test_process.ProcessRecoveryTests.test_identical_key_suppresses_late_original'),
    ('disable_original_fence', "if state == 'cancelled':", 'if False:',
     'test_process.ProcessRecoveryTests.test_terminal_fence_blocks_late_original'),
)
rows = []
for name, before, after, test in cases:
    out = root / name
    out.mkdir()
    for source in frozen.glob('*.py'):
        shutil.copyfile(source, out / source.name)
    service = out / 'service.py'
    text = service.read_text()
    assert text.count(before) == 1
    service.write_text(text.replace(before, after))
    (out / 'mutation.json').write_text(json.dumps(dict(before=before, after=after, test=test), indent=2)+'\n')
    result = subprocess.run([sys.executable, '-B', '-m', 'unittest', '-v', test], cwd=out, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / 'test-output.txt').write_text(result.stdout)
    rows.append(dict(name=name, returncode=result.returncode, rejected=result.returncode!=0))
(root / 'results.json').write_text(json.dumps(rows, indent=2)+'\n')
print(json.dumps(rows, indent=2))
assert all(r['rejected'] for r in rows)
